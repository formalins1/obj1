﻿
function del(id){
	if(confirm("真的要删除 吗？")){
		location.href = "rootusers/del?id=" + id;
	}
}

function f() {
	confirm("fffff");
}
