package com.qq.model;

public class User {
	private int id;
	private String name;
	private String password;
	private String nick;
	private String addr;
	private int typee;
	private String type1;
	
	public User() {}

	public User(int id, String name, String password, String nick, String addr) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.nick = nick;
		this.addr = addr;
	}

	public User(int id, String name, String password, String nick, String addr, int typee) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.nick = nick;
		this.addr = addr;
		this.typee = typee;
	}

	public User(int id, String name, String password, String nick, String addr, String type1) {
		this.id = id;
		this.name = name;
		this.password = password;
		this.nick = nick;
		this.addr = addr;
		this.type1 = type1;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNick() { return nick; }

	public void setNick(String nick) { this.nick = nick; }

	public String getAddr() { return addr; }

	public void setAddr(String addr) { this.nick = addr; }

	public int getTypee() { return typee; }

	public void setTypee(String typee) { this.nick = typee; }

	public String getType1() { return type1; }

	public void setType1(String type) { this.nick = type1; }
}
