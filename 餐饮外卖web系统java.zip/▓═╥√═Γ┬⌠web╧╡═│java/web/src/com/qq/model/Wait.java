package com.qq.model;

public class Wait {

    private int id;
    private String time;
    private String addr;
    private String orderr;
    private double price;
    private String name;
    private String complete;

    public Wait() {}

    public Wait(String time, String addr, String orderr, double price, String name){
        this.time = time;
        this.addr = addr;
        this.orderr = orderr;
        this.price = price;
        this.name = name;
    }

    public Wait(String time, String addr, String orderr, double price, String name, String complete){
        this.time = time;
        this.addr = addr;
        this.orderr = orderr;
        this.price = price;
        this.name = name;
        this.complete = complete;
    }

    public Wait(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public Wait(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public Wait(String time) {
        this.time = time;
    }



    public Wait(int id, String name, String time, String addr, String orderr, double price, String complete){
        this.id = id;
        this.time = time;
        this.addr = addr;
        this.orderr = orderr;
        this.price = price;
        this.name = name;
        this.complete = complete;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getAddr() {
        return addr;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getOrderr() {
        return orderr;
    }

    public void setOrderr(String orderr) { this.orderr = orderr; }

    public String getComplete() {
        return complete;
    }

    public void setComplete(String complete) {
        this.complete = complete;
    }




    @Override
    public String toString() {
        return "Book [id=" + id + ", name=" + name + ", price=" + price + ", time=" + time + ", addr=" + addr + ", order=" + orderr + ", complete=" + complete + "]";
    }

}
