package com.qq.filter;

import com.qq.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;


@WebFilter("/customer/*")
public class UserFilter implements Filter{
	@Override
	public void destroy() {}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		HttpServletRequest hreq= (HttpServletRequest)request;
		HttpSession session = hreq.getSession();
		
		User u = (User)session.getAttribute("USER");
		if(u==null) {
			
			((HttpServletResponse)response).sendRedirect(hreq.getContextPath() + "/login");
		}else {
			chain.doFilter(request, response);
		}
	}
}
