package com.qq.servlet;

import com.qq.model.User;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class LoginServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		RequestDispatcher dispatcher= req.getRequestDispatcher("/login/index.jsp");
		dispatcher.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		if (req.getParameter("judge") != null){
			String username = req.getParameter("name");
			String password = req.getParameter("pass");


			Connection con = DBUtil.getConnection();
			try {
				Statement stmt = con.createStatement();
				String sql = "Select * From user Where name='" + username + "' AND password = '" + password + "'";
				ResultSet rs = stmt.executeQuery(sql);

				if (rs.next()) {//?ж?rs ???? ???????????????

					int typer = rs.getInt("typee");
					int id = rs.getInt("id");
					String name = rs.getString("name");
					String nick = rs.getString("nick");
					String addr = rs.getString("addr");

					HttpSession session = req.getSession();
					session.setAttribute("USER", new User(id, name, password, nick, addr));
					if(typer == 0)
						resp.sendRedirect("customer");//????? ???????????????
					if(typer == 1)
						resp.sendRedirect("staff/cook");
					if(typer == 2)
						resp.sendRedirect("staff/rece");
					if(typer == 3)
						resp.sendRedirect("root");
				} else {
					resp.sendRedirect("login"); //????? ??  ????????
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		else{
			String regname = req.getParameter("regname");
			String renick = req.getParameter("renick");
			String regpass = req.getParameter("regpass");
			int type = 0;

			Connection con = DBUtil.getConnection();
			try {
				Statement stmt = con.createStatement();
				String sql = "Insert into user(name,nick,password,typee) values('" + regname + "', '" + renick + "', '" + regpass + "'," + type + ")";
				int num = stmt.executeUpdate(sql);

				if(num>0) {

					resp.sendRedirect("login");
				}else {
					resp.getWriter().println("fail");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}


		}
	}

}
