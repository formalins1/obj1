package com.qq.servlet.cust;

import com.qq.model.User;
import com.qq.model.Wait;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/customer/wait")
public class CustwaitServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		try {
            HttpSession session = req.getSession();
            User user1 = (User)session.getAttribute("USER");
            String na = user1.getName();

			Connection con= DBUtil.getConnection();

			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery("Select * From  wait where name='" + na + "'");
            List<Wait> waits = new ArrayList<Wait>();
			while(rs.next()) {
				int id = rs.getInt("id");
				String time = rs.getString("time");
				String addr = rs.getString("addr");
				String orderr = rs.getString("orderr");
                double price = rs.getDouble("price");
                String name = rs.getString("name");
				int comp = rs.getInt("complete");
				String complete = null;
				if(comp == 0)
					complete = "等待确认";
				if(comp == 1)
					complete = "正在制作";
				if(comp == 2)
					complete = "正在派送";
				Wait b = new Wait(id,name,time,addr,orderr, price, complete);
				waits.add(b);
			}
			req.setAttribute("WAIT", waits);
            /*
            HttpSession session = req.getSession();
			User user1 = (User)session.getAttribute("USER");
			String na = user1.getNick();
			req.setAttribute("na", na);
             */

			RequestDispatcher dispatcher = req.getRequestDispatcher("/customer/wait.jsp");
			dispatcher.forward(req, resp);
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
