package com.qq.servlet.cust;

import com.qq.model.Food;
import com.qq.model.User;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@WebServlet("/customer")
public class CustindexServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			HttpSession session = req.getSession();
			User user = (User)session.getAttribute("USER");
			String ni = user.getName();
			Connection con = DBUtil.getConnection();
			Statement stmt4 = con.createStatement();
			ResultSet rs = stmt4.executeQuery("Select * From  user where name='" + ni + "'");
			while (rs.next()) {
				if (rs.getString("addr") == null) {
					break;
				}
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}

		try {
			Connection con= DBUtil.getConnection();
			Statement stmt4 = con.createStatement();

			ResultSet rs = stmt4.executeQuery("Select * From  menu");
			List<Food>  books = new ArrayList<Food>();
			while(rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				double price = rs.getDouble("price");
				Food b = new Food(id,name,price);
				books.add(b);
			}
			req.setAttribute("BOOKS", books);

			HttpSession session = req.getSession();
			User user1 = (User)session.getAttribute("USER");
			String ni = user1.getNick();
			req.setAttribute("na", ni);

			String na = user1.getName();
			Connection waiter= DBUtil.getConnection();
			Statement waiter1 = waiter.createStatement();
			ResultSet waiter2 = waiter1.executeQuery("Select * From  wait where name='" + na + "'");
			int pd = 0;
			while(waiter2.next())
				if(waiter2.getInt("complete") == 0 || waiter2.getInt("complete") == 1 ||waiter2.getInt("complete") == 2) {
					pd = 1;
					break;
				}
			if(pd == 1)
				req.setAttribute("wait", "正在等候...");
			else
				req.setAttribute("wait", "无订单");
			RequestDispatcher dispatcher = req.getRequestDispatcher("/customer/index.jsp");
			dispatcher.forward(req, resp);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}

	}
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String[] array = req.getParameterValues("vehicle");
			Connection abc = DBUtil.getConnection();
			Statement stmt3 = abc.createStatement();
			double allprice1 = 0;
			String ord = null;
			String order = null;
			for(String s : array) {
				ResultSet stmt33 = stmt3.executeQuery("Select * From  menu where id=" + s);
				if(stmt33.next())
					allprice1 += stmt33.getDouble("Price");
			}

			String allprice2 = String.format("%.2f", allprice1);
			double allprice = Double.parseDouble(allprice2);
			for(String s : array){
				ResultSet stmt333 = stmt3.executeQuery("Select * From  menu where id=" + s);
				if(stmt333.next())
					ord = stmt333.getString("name");
					if(order == null)
						order = ord;
					else
						order = order + "、" + ord;
			}


			HttpSession session = req.getSession();
			User user1 = (User)session.getAttribute("USER");
			String  namer = user1.getName();

			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			String time = df.format(new Date());

			Connection adr = DBUtil.getConnection();
			Statement stmt = adr.createStatement();
			ResultSet getaddr = stmt.executeQuery("Select * From  user where name='" + namer + "'");
			if(getaddr.next()) {
				String getaddrr = getaddr.getString("addr");

				Connection addin = DBUtil.getConnection();
				Statement stmt2 = addin.createStatement();
				String sql = "Insert into wait(name,addr,time,orderr,price) values('" + namer + "', '" + getaddrr + "', '" + time + "','" + order + "'," + allprice + ")";
				stmt2.executeUpdate(sql);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		resp.sendRedirect("customer/wait");
	}
}
