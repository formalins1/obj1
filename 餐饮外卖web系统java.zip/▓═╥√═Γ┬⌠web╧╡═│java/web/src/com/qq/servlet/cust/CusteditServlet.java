package com.qq.servlet.cust;

import com.qq.model.User;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/customer/edit")
public class CusteditServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user1 = (User)session.getAttribute("USER");
		int id = user1.getId();

		Connection con = DBUtil.getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select * From user Where id=" + id);
			User user = null;
			if(rs.next()) {
				String pa = rs.getString("password");
				String nick = rs.getString("nick");
				String addr = rs.getString("addr");
				user = new User(1,"s", pa,nick,addr);
			}
			req.setAttribute("BOOK", user);
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	   RequestDispatcher dispatcher =  req.getRequestDispatcher("/customer/edit.jsp");
	   dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession();
		User user1 = (User)session.getAttribute("USER");
		int id = user1.getId();
		String nick = req.getParameter("nick");
		String pa = req.getParameter("password");
		String add = req.getParameter("addr");
		
		try {
			Connection con = DBUtil.getConnection();
			Statement stmt = con.createStatement();
			String sql = "Update user Set nick='"+ nick + "', password= '"+ pa +"', addr='"+ add +"' Where id=" + id;
			stmt.executeUpdate(sql);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		resp.sendRedirect("../customer");
	}
}
