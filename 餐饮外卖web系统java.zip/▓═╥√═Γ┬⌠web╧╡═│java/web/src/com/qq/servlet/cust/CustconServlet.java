package com.qq.servlet.cust;

import com.qq.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/customer/con")
public class CustconServlet extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String id1 = req.getParameter("id");
        int id = Integer.parseInt(id1);

        Connection con = DBUtil.getConnection();
        try {
            Statement stmt = con.createStatement();
            Statement stmt1 = con.createStatement();
            Statement stmt2 = con.createStatement();
            ResultSet rs = stmt.executeQuery("Select * From wait Where id=" + id);

            stmt1.executeUpdate("Delete From wait Where id=" + id);
            String name = null;
            String time = null;
            String addr = null;
            String orderr = null;
            double price = 0;
            while (rs.next()) {
                name = rs.getString("name");
                time = rs.getString("time");
                addr = rs.getString("addr");
                orderr = rs.getString("orderr");
                price = rs.getDouble("price");
            }
            String sql = "Insert into record(name,time,addr,orderr,price) values('" + name + "', '" + time + "', '" + addr + "', '" + orderr + "', " + price + ")";
            stmt2.executeUpdate(sql);

            resp.sendRedirect("wait");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
