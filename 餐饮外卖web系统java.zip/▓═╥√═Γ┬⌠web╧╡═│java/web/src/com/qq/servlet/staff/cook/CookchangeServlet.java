package com.qq.servlet.staff.cook;

import com.mysql.jdbc.Connection;
import com.qq.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


@WebServlet("/staff/cook/edit")
public class CookchangeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String id = req.getParameter("id");
            //查所有书籍
            Connection con= (Connection) DBUtil.getConnection();
            //创建命令
            Statement stmt = con.createStatement();
            Statement stmt1 = con.createStatement();
            //查询，获得记录集
            ResultSet rs = stmt.executeQuery("Select * From  wait where id=" + id);
            if(rs.next()) {
                if (rs.getInt("complete") == 1) {
                    String sql = "Update wait Set complete=" + 2 + " Where id=" + id;
                    stmt1.executeUpdate(sql);
                }
            }
            resp.sendRedirect("../cook");
            //显示到一个  jsp页面中

        }catch(SQLException e) {
            e.printStackTrace();
        }

    }
}
