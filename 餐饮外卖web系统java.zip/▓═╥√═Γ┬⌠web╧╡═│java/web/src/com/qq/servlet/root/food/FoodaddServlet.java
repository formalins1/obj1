package com.qq.servlet.root.food;

import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/root/food/add")
public class FoodaddServlet extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        RequestDispatcher dispatcher =  req.getRequestDispatcher("/root/food/add.jsp");
        dispatcher.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String id = req.getParameter("id");
        String name = req.getParameter("name");
        String price= req.getParameter("price");

        try {
            Connection con = DBUtil.getConnection();
            Statement stmt = con.createStatement();
            String sql = "Insert into menu(id,name,price) values('" + id + "', '" + name + "', " + price + ")";
            stmt.executeUpdate(sql);
        }catch(SQLException e) {
            e.printStackTrace();
        }

        resp.sendRedirect("../food");
    }


}