package com.qq.servlet.root.food;

import com.mysql.jdbc.Connection;
import com.qq.model.Food;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/root/food")
public class FoodindexServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {

            Connection con= (Connection) DBUtil.getConnection();

            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery("Select * From  menu");
            List<Food> foods = new ArrayList<Food>();
            while(rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                double price = rs.getDouble("price");

                Food b = new Food(id,name,price);
                foods.add(b);
            }

            req.setAttribute("BOOKS", foods);


            RequestDispatcher dispatcher = req.getRequestDispatcher("/root/food/fod.jsp");
            dispatcher.forward(req, resp);

        }catch(SQLException e) {
            e.printStackTrace();
        }

    }
}
