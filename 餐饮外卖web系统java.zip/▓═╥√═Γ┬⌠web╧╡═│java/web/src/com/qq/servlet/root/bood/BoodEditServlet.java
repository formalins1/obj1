package com.qq.servlet.root.bood;

import com.qq.model.User;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/root/rootuser/edit")
public class BoodEditServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


		String id = req.getParameter("id");
		Connection con = DBUtil.getConnection();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("Select * From user Where id=" + id);
			User user = null;
			if(rs.next()) {
				int id2 = rs.getInt("id");
				String name = rs.getString("name");
				String password = rs.getString("password");
				String nick = rs.getString("nick");
				String addr = rs.getString("addr");
				int typee = rs.getInt("typee");
				user = new User(id2, name, password, nick, addr, typee);
			}
			req.setAttribute("BOOK", user);
		}
		catch(SQLException e) {
			e.printStackTrace();
		}

	   RequestDispatcher dispatcher =  req.getRequestDispatcher("/root/rootusers/edit.jsp");
	   dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String id = req.getParameter("id");
		String name = req.getParameter("name");
		String password= req.getParameter("password");
		String nick = req.getParameter("nick");
		String addr = req.getParameter("addr");
		String typee = req.getParameter("typee");
		
		try {
			Connection con = DBUtil.getConnection();
			Statement stmt = con.createStatement();
			String sql = "Update user Set name='"+ name + "', password='" + password + "', nick= '" + nick + "', addr= '" + addr + "', typee=" + typee + " Where id=" + id;
			stmt.executeUpdate(sql);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		resp.sendRedirect("../rootuser");
	}
}
