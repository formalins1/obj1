package com.qq.servlet.root.bood;

import com.mysql.jdbc.Connection;
import com.qq.model.User;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/root/rootuser")
public class BoodcusServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {

			Connection con= (Connection) DBUtil.getConnection();

			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery("Select * From  user");
			List<User> users = new ArrayList<User>();
			while(rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String nick = rs.getString("nick");
				String password = rs.getString("password");
				String addr = rs.getString("addr");
				 int type = rs.getInt("typee");
				 String type1 = null;
				 if(type == 0)
				 	type1 = "顾客";
				 else
				 	if(type == 1)
				 		type1 = "厨师";
				 	else
				 		if(type == 2)
				 			type1 = "前台";
				 		else
				 			type1 = "管理员";
				User b = new User(id,name,nick,password,addr,type1);
				users.add(b);
			}

			req.setAttribute("BOOKS", users);


			RequestDispatcher dispatcher = req.getRequestDispatcher("/root/rootusers/cus.jsp");
			dispatcher.forward(req, resp);

		}catch(SQLException e) {
			e.printStackTrace();
		}

	}
}
