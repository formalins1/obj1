package com.qq.servlet.root.food;

import com.qq.util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/root/food/del")
public class FooddelServlet extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");

        Connection con = DBUtil.getConnection();
        try {
            Statement stmt = con.createStatement();
            int num = stmt.executeUpdate("Delete From menu Where id=" + id);
            resp.sendRedirect("../food");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
