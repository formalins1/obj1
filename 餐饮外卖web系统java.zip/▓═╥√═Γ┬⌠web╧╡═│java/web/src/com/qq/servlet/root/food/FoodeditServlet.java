package com.qq.servlet.root.food;

import com.qq.model.Food;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/root/food/edit")
public class FoodeditServlet extends HttpServlet{
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {


        String id = req.getParameter("id");
        Connection con = DBUtil.getConnection();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("Select * From menu Where id=" + id);
            Food book = null;
            if(rs.next()) {
                int id2 = rs.getInt("id");
                String name = rs.getString("name");
                double price = rs.getDouble("price");
                book = new Food(id2, name, price);
            }
            req.setAttribute("BOOK", book);
        }
        catch(SQLException e) {
            e.printStackTrace();
        }

        RequestDispatcher dispatcher =  req.getRequestDispatcher("/root/food/edit.jsp");
        dispatcher.forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String id = req.getParameter("id");
        String name = req.getParameter("name");
        String price= req.getParameter("price");

        try {
            Connection con = DBUtil.getConnection();
            Statement stmt = con.createStatement();
            String sql = "Update menu Set name='"+ name + "', price='" + price + "' Where id=" + id;
            stmt.executeUpdate(sql);
        }catch(SQLException e) {
            e.printStackTrace();
        }

        resp.sendRedirect("../food");
    }
}
