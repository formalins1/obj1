package com.qq.servlet.root.record;

import com.mysql.jdbc.Connection;
import com.qq.model.Wait;
import com.qq.util.DBUtil;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


@WebServlet("/root/record")
public class RecordindexServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            //查所有书籍
            Connection con= (Connection) DBUtil.getConnection();
            //创建命令
            Statement stmt = con.createStatement();
            //查询，获得记录集
            ResultSet rs = stmt.executeQuery("Select * From  record");
            List<Wait> rec = new ArrayList<Wait>();
            while(rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String time = rs.getString("time");
                String addr = rs.getString("addr");
                String orderr = rs.getString("orderr");
                double price = rs.getDouble("price");
                String complete = "3";
                Wait b = new Wait(id,name,time,addr,orderr,price, complete);
                rec.add(b);
            }

            req.setAttribute("BOOKS", rec);

            //显示到一个  jsp页面中
            RequestDispatcher dispatcher = req.getRequestDispatcher("/root/record/rec.jsp");
            dispatcher.forward(req, resp);

        }catch(SQLException e) {
            e.printStackTrace();
        }

    }
}
