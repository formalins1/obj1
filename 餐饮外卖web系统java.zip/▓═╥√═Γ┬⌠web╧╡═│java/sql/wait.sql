INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (5, '2020-06-23 10:56:57', '阿富汗', '老八蜜汁小憨包儿', 2, 5.00, 'yao');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (10, '2020-06-23 21:16:02', '琉璃玛丽苏之国', '陈年金针菇、老干爹、牛奶老萝卜花甲', 0, 43.00, 'jing');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (11, '2020-06-23 21:16:13', '琉璃玛丽苏之国', '陈年金针菇、老干爹、芝士炸鸡、牛奶老萝卜花甲', 2, 141.00, 'jing');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (12, '2020-06-23 21:16:19', '琉璃玛丽苏之国', '西红柿鸡蛋', 0, 8.00, 'jing');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (13, '2020-06-23 21:16:27', '琉璃玛丽苏之国', '五香小龙虾', 1, 50000.00, 'jing');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (14, '2020-06-23 21:16:32', '琉璃玛丽苏之国', '牛奶老萝卜花甲', 0, 11.50, 'jing');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (15, '2020-06-24 00:53:49', '琉璃玛丽苏之国', '阿龙炒饭Pro', 0, 9.00, 'jing');
INSERT INTO `wait`(`id`, `time`, `addr`, `orderr`, `complete`, `price`, `name`) VALUES (17, '2020-06-24 10:43:18', '', '祖宗椰树牌椰汁', 2, 5.00, 'ASD');
