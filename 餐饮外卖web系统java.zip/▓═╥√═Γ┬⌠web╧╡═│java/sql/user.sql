INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('root', '123', 1, '欧祥大老板', 3, '华盛顿白宫');
INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('tyx', '123', 11, '唐小二', 1, '印度贫民窑');
INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('jie', '123', 12, '杰尼龟', 2, '荣昌');
INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('yao', '123', 13, '姚导演', 0, '阿富汗');
INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('jing', '123', 14, '赵高级数据科学家', 0, '琉璃玛丽苏之国');
INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('贵宾卡', 'cjycjy', 15, '红红火火', 0, NULL);
INSERT INTO `user`(`name`, `password`, `id`, `nick`, `typee`, `addr`) VALUES ('ASD', '123', 16, 'ASDQWE', 0, '');
