INSERT INTO `menu`(`id`, `name`, `Price`) VALUES (1, '轻食套餐', 30.00);
INSERT INTO `menu`(`id`, `name`, `Price`) VALUES (2, '阿龙炒饭Pro', 9.00);
INSERT INTO `menu`(`id`, `name`, `Price`) VALUES (3, '麻辣冰淇淋', 3.00);
INSERT INTO `menu`(`id`, `name`, `Price`) VALUES (4, '陈年金针菇', 19.50);
