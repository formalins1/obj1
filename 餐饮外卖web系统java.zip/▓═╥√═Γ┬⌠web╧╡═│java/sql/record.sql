INSERT INTO `record`(`id`, `name`, `time`, `addr`, `orderr`, `price`) VALUES (1, 'yao', '2020-06-23 10:56:39', '阿富汗', '麻辣冰淇淋', 3.00);
INSERT INTO `record`(`id`, `name`, `time`, `addr`, `orderr`, `price`) VALUES (2, 'jinger', '2020-06-23 11:13:13', 'null', '阿龙炒饭Pro', 9.00);
INSERT INTO `record`(`id`, `name`, `time`, `addr`, `orderr`, `price`) VALUES (3, 'jing', '2020-06-23 15:40:11', '琉璃玛丽苏之国', '西红柿鸡蛋、红烧肉', 8.00);
INSERT INTO `record`(`id`, `name`, `time`, `addr`, `orderr`, `price`) VALUES (11, 'ASD', '2020-06-24 10:39:26', 'null', '芝士炸鸡、土豆丝', 107.00);
