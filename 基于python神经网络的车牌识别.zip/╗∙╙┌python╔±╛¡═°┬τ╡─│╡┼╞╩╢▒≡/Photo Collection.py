# coding:utf8
from __future__ import print_function
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import cv2
from imutils.perspective import four_point_transform
import imutils
import scipy.special
import threading
import numpy
import time
import cv2 as cv
chepai = ''
class neuralNetwork:

    def __init__(self, inputnodes, hiddennodes, outputnodes, learningrate):
        self.inodes = inputnodes
        self.hnodes = hiddennodes
        self.onodes = outputnodes

        self.wih = np.random.normal(0.0, pow(self.inodes, -0.5), (self.hnodes, self.inodes))
        self.who = np.random.normal(0.0, pow(self.hnodes, -0.5), (self.onodes, self.hnodes))
        self.lr = learningrate
        self.activation_function = lambda x: scipy.special.expit(x)

        pass

    # train the neural network
    def train(self, inputs_list, targets_list):
        # convert inputs list to 2d array
        inputs = numpy.array(inputs_list, ndmin=2).T
        targets = numpy.array(targets_list, ndmin=2).T

        # calculate signals into hidden layer
        hidden_inputs = numpy.dot(self.wih, inputs)
        # calculate the signals emerging from hidden layer
        hidden_outputs = self.activation_function(hidden_inputs)

        # calculate signals into final output layer
        final_inputs = numpy.dot(self.who, hidden_outputs)
        # calculate the signals emerging from final output layer
        final_outputs = self.activation_function(final_inputs)

        # output layer error is the (target - actual)
        output_errors = targets - final_outputs
        # hidden layer error is the output_errors, split by weights, recombined at hidden nodes
        hidden_errors = numpy.dot(self.who.T, output_errors)

        # update the weights for the links between the hidden and output layers
        self.who += self.lr * numpy.dot((output_errors * final_outputs * (1.0 - final_outputs)),
                                        numpy.transpose(hidden_outputs))

        # update the weights for the links between the input and hidden layers
        self.wih += self.lr * numpy.dot((hidden_errors * hidden_outputs * (1.0 - hidden_outputs)),
                                        numpy.transpose(inputs))

        pass

    # query the neural network
    def query(self, inputs_list):
        # convert inputs list to 2d array
        inputs = np.array(inputs_list, ndmin=2).T

        # calculate signals into hidden layer
        hidden_inputs = np.dot(self.wih, inputs)
        # calculate the signals emerging from hidden layer
        hidden_outputs = self.activation_function(hidden_inputs)

        # calculate signals into final output layer
        final_inputs = np.dot(self.who, hidden_outputs)
        # calculate the signals emerging from final output layer
        final_outputs = self.activation_function(final_inputs)

        return final_outputs

        pass

    def judge(self, inputs):
        inputs = (np.asfarray(inputs[1:]) / 255.0 * 0.99) + 0.01
        outputs = self.query(inputs)
        label = np.argmax(outputs)

        return label

        pass

    def save(self, network_name):
        np.savetxt("Weight matrix\\" + network_name + "\\wih.csv", self.wih, delimiter=',')
        np.savetxt("Weight matrix\\" + network_name + "\\who.csv", self.who, delimiter=',')
        pass

    def load(self, network_name):
        self.wih = np.loadtxt("Weight matrix\\" + network_name + "\\wih.csv", delimiter=',')
        self.who = np.loadtxt("Weight matrix\\" + network_name + "\\who.csv", delimiter=',')
        pass
        pass


class Judge_Thread(threading.Thread):
    a_foreign_data_list = []
    result = []
    final_result = ''
    NL = {'input_nodes': 784, 'hidden_nodes': 200, 'output_nodes': 34, 'learning_rate': 0.1}
    C = {'input_nodes': 1024, 'hidden_nodes': 200, 'output_nodes': 6, 'learning_rate': 0.1}
    L = {'input_nodes': 784, 'hidden_nodes': 200, 'output_nodes': 24, 'learning_rate': 0.1}
    Alphabetic_and_Letter_Dictionary = {0: '0', 1: '1', 2: '2', 3: '3', 4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9',
                                        10: 'A', 11: 'B', 12: 'C', 13: 'D', 14: 'E', 15: 'F', 16: 'G', 17: 'H', 18: 'J',
                                        19: 'K', 20: 'L', 21: 'M', 22: 'N', 23: 'p', 24: 'Q', 25: 'R', 26: 'S', 27: 'T',
                                        28: 'U', 29: 'V', 30: 'W', 31: 'X', 32: 'Y', 33: 'Z'}
    Alphabetic_Dictionary = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G', 7: 'H', 8: 'J',
                                        9: 'K', 10: 'L', 11: 'M', 12: 'N', 13: 'p', 14: 'Q', 15: 'R', 16: 'S', 17: 'T',
                                        18: 'U', 19: 'V', 20: 'W', 21: 'X', 22: 'Y', 23: 'Z'}
    Chinese_Characters_Dictionary = {0: '京', 1: '闽', 2: '粤', 3: '苏', 4: '沪', 5: '浙', 6: '渝'}
    Numbers_and_letters_Network = neuralNetwork(NL['input_nodes'], NL['hidden_nodes'], NL['output_nodes'],
                                                NL['learning_rate'])
    Chinese_Characters_Network = neuralNetwork(C['input_nodes'], C['hidden_nodes'], C['output_nodes'],
                                               C['learning_rate'])
    Letters_Network = neuralNetwork(L['input_nodes'], L['hidden_nodes'], L['output_nodes'], L['learning_rate'])


    def __init__(self, threadID):
        threading.Thread.__init__(self)
        self.threadID = threadID
        self.Numbers_and_letters_Network.load("Numbers_and_letters")
        self.Chinese_Characters_Network.load("Chinese_Characters")
        self.Letters_Network.load("Letters")

        pass

    def run(self):
        while True:
            try:
                last_judge_data_list = self.a_foreign_data_list
                self.result = []
                self.result.append(self.Chinese_Characters_Dictionary[self.Chinese_Characters_Network.judge(last_judge_data_list[0])])
                self.result.append(self.Alphabetic_Dictionary[self.Letters_Network.judge(last_judge_data_list[1])])
                self.result.append(self.Alphabetic_and_Letter_Dictionary[self.Numbers_and_letters_Network.judge(last_judge_data_list[2])])
                self.result.append(self.Alphabetic_and_Letter_Dictionary[self.Numbers_and_letters_Network.judge(last_judge_data_list[3])])
                self.result.append(self.Alphabetic_and_Letter_Dictionary[self.Numbers_and_letters_Network.judge(last_judge_data_list[4])])
                self.result.append(self.Alphabetic_and_Letter_Dictionary[self.Numbers_and_letters_Network.judge(last_judge_data_list[5])])
                self.result.append(self.Alphabetic_and_Letter_Dictionary[self.Numbers_and_letters_Network.judge(last_judge_data_list[6])])
                self.final_result = ''.join(self.result[:2]) + '·' + ''.join(self.result[2:])
            except IndexError:
                pass
            time.sleep(1)
            pass

    pass


cap = cv2.VideoCapture(0)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)



#xxx = 0
x = 5
#flag = 1
docCnt = ([[0,0]],[[1,0]],[[0,1]],[[1,1]])

_Judge_Thread = Judge_Thread(0)
_Judge_Thread.setDaemon(True)
_Judge_Thread.start()

while (True):

    ret, frame = cap.read()
    #cv2.imshow("win3", frame)
    blurred = cv2.GaussianBlur(frame, (5, 5), 0)
    dilate = cv2.dilate(blurred, cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3)))
    edged = cv2.Canny(dilate, 30, 120, 3)  # 边缘检测
    cnts = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)  # 轮廓检测
    #print(cnts)
    cnts = cnts[0] if imutils.is_cv2() else cnts[1]

    if x == 5:
        if len(cnts) > 0:
            cnts = sorted(cnts, key=cv2.contourArea, reverse=True)  # 根据轮廓面积从大到小排序
            for c in cnts:
                peri = cv2.arcLength(c, True)  # 计算轮廓周长
                approx = cv2.approxPolyDP(c, 0.02 * peri, True)  # 轮廓多边形拟合
                if len(approx) == 4:
                    docCnt = approx
                    #print(docCnt)
                    break

        pts = np.array([docCnt], np.int32)
        pts = pts.reshape((-1, 1, 2))
        #print(pts)

    if abs(docCnt[0][0][0] - docCnt[2][0][0]) >= 80 and abs(docCnt[0][0][1] - docCnt[2][0][1]) >= 45:
        if x == 5:
            #cv2img = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
            pilimg = Image.fromarray(frame)
            draw = ImageDraw.Draw(pilimg)  # 图片上打印
            font = ImageFont.truetype("typeface.ttf", 50, encoding="utf-8")  # 参数1：字体文件路径，参数2：字体大小
            draw.text(((docCnt[2][0][0]+docCnt[0][0][0])//2-130, docCnt[0][0][1]-60), _Judge_Thread.final_result, (0, 0, 0), font=font)  # 参数1：打印坐标，参数2：文本，参数3：字体颜色，参数4：字体

        frame = cv2.cvtColor(np.array(pilimg), cv2.COLOR_RGB2BGR)# PIL图片转cv2 图片
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    cv2.polylines(frame, [pts], True, (0, 0, 255))

    cv2.imshow("win1", frame)
    k = cv2.waitKey(1) & 0xFF
    if x == 10:

        if abs(docCnt[0][0][0] - docCnt[2][0][0]) >= 80 and abs(docCnt[0][0][1] - docCnt[2][0][1]) >= 45:

            #cv2.imshow('img', img)
            result_img = four_point_transform(frame, docCnt.reshape(4, 2))

            #cv2.imwrite(r'photo/5.jpg', result_img)
            img = Image.fromarray(result_img)
            #img = Image.open(r'photo/5.jpg')
            img = img.convert("L")
            threshold = 180
            table = []
            for i in range(256):
                if i < threshold:
                    table.append(0)
                else:
                    table.append(1)
            img = img.point(table, '1')
            img.save(r'photo/6.jpg')
            zzz = cv.imread(r'photo/6.jpg')
            cv2.imshow('win2', zzz)
            im = Image.open(r'photo/6.jpg')
            #im = img
            img_c = im.crop([im.size[0] * 2 / 96, im.size[1] / 8, im.size[0] * 94 / 96, im.size[1] * 7 / 8])

            img_1 = img_c.crop([0, 0, img_c.size[0] // 6.50, img_c.size[1]])
            img_2 = img_c.crop([img_c.size[0] // 6.80, 0, img_c.size[0] // 3.65, img_c.size[1]])
            img_3 = img_c.crop([img_c.size[0] // 3.05, 0, img_c.size[0] // 2.07, img_c.size[1]])
            img_4 = img_c.crop([img_c.size[0] // 2.15, 0, img_c.size[0] // 1.64, img_c.size[1]])
            #img_4.save(r'phot0/%d.jpg'%xxx)
            img_5 = img_c.crop([img_c.size[0] // 1.67, 0, img_c.size[0] // 1.35, img_c.size[1]])
            img_6 = img_c.crop([img_c.size[0] // 1.37, 0, img_c.size[0] // 1.16, img_c.size[1]])
            #img_6.save(r'phot8/%d.jpg'%xxx)
            img_7 = img_c.crop([img_c.size[0] // 1.16, 0, img_c.size[0], img_c.size[1]])
            #img_7.save(r'phot6/%d.jpg'%xxx)
            #xxx = xxx + 1
            """
            img_1.show()
            img_2.show()
            img_3.show()
            img_4.show()
            img_5.show()
            img_6.show()
            img_7.show()
            """
            img_1 = img_1.resize((32, 32), Image.ANTIALIAS)
            # img_1.show()
            csv2 = []
            csv1 = []
            csv1.append(0)
            for i in range(32):
                for j in range(32):
                    b = img_1.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            csv2.append(csv1)
            #with open(r'word_csv/word_1.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #csv_writer.writerow(csv1)

            img_2 = img_2.resize((28, 28), Image.ANTIALIAS)
            # img_2.show()
            csv1 = []
            csv1.append(0)
            for i in range(28):
                for j in range(28):
                    b = img_2.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            #with open(r'word_csv/word_2.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #csv_writer.writerow(csv1)
            csv2.append(csv1)

            img_3 = img_3.resize((28, 28), Image.ANTIALIAS)
            # img_3.show()
            csv1 = []
            csv1.append(0)
            for i in range(28):
                for j in range(28):
                    b = img_3.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            #with open(r'word_csv/word_3.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #csv_writer.writerow(csv1)
            csv2.append(csv1)

            img_4 = img_4.resize((28, 28), Image.ANTIALIAS)
            # img_4.show()
            csv1 = []
            csv1.append(0)
            for i in range(28):
                for j in range(28):
                    b = img_4.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            #with open(r'word_csv/word_4.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #csv_writer.writerow(csv1)
            csv2.append(csv1)

            img_5 = img_5.resize((28, 28), Image.ANTIALIAS)
            # img_5.show()
            csv1 = []
            csv1.append(0)
            for i in range(28):
                for j in range(28):
                    b = img_5.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            #with open(r'word_csv/word_5.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #csv_writer.writerow(csv1)
            csv2.append(csv1)

            img_6 = img_6.resize((28, 28), Image.ANTIALIAS)
            # img_6.show()
            csv1 = []
            csv1.append(0)
            for i in range(28):
                for j in range(28):
                    b = img_6.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            #with open(r'word_csv/word_6.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #csv_writer.writerow(csv1)
            csv2.append(csv1)

            img_7 = img_7.resize((28, 28), Image.ANTIALIAS)
            # img_7.show()
            csv1 = []
            csv1.append(0)
            for i in range(28):
                for j in range(28):
                    b = img_7.getpixel((j, i))
                    # print(b)
                    # cc = (b[0] + b[1] + b[2]) // 3
                    # cc = 255 - cc
                    csv1.append(b)
            csv2.append(csv1)
            _Judge_Thread.a_foreign_data_list = csv2

            #with open('word.csv', 'w', newline='') as t_file:
                #csv_writer = csv.writer(t_file)
                #for num in range(7):
                    #csv_writer.writerow(csv2[num])



            """
            color_photo = Image.open(r'photo/5.jpg')
            color_pixel = color_photo.getpixel((im.size[0] // 3.35, im.size[1] // 1.25))
            if color_pixel[0] > 80 and color_pixel[1] < 35 and color_pixel[2] < 35:
                www = '车牌为蓝色'
            elif color_pixel[0] < 35 and color_pixel[1] > 100 and color_pixel[2] > 100:
                www = '车牌为黄色'
            elif color_pixel[0] < 35 and color_pixel[1] < 35 and color_pixel[2] < 35:
                www = '车牌为黑色'
            elif color_pixel[0] < 35 and color_pixel[1] > 100 and color_pixel[2] < 35:
                www = '车牌为绿色'
            elif color_pixel[0] > 100 and color_pixel[1] > 100 and color_pixel[2] > 100:
                www = '车牌为白色'
            elif color_pixel[0] < 35 and color_pixel[1] < 35 and color_pixel[2] > 100:
                www = '车牌为红色(中国无红色车牌)'
            """

        else:
            jpg0 = cv2.imread(r'photo/0.jpg')
            cv2.imshow('win2', jpg0)

    x = x + 1
    if x == 11:
        x = 1

cap.release()
cv2.destroyAllWindows()
